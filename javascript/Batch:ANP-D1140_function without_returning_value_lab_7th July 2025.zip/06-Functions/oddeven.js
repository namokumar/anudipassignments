// Question 2 : Write a javascript to input any number and check it is natural number or not.

"use strict";
function oddEven() {
    let n;
    n = parseInt(prompt("Enter a Number: "));
    if (n % 2 == 0) {
        document.write(n + " is Even Number: ");
    }
    else {
        document.write(n + " is Odd Number: ");
    }
}
